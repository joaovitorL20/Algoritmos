/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float km, dias, valor_total;
    printf("Quantos km foram percorridos?");
    scanf("%f", &km);
    
    printf("Quantos dias o carro foi alugado?");
    scanf("%f", &dias);
    
    valor_total= km*0.20 + dias*90;
    
    printf("O valor total a ser pago vai ser %2f", valor_total);

    return 0;
}